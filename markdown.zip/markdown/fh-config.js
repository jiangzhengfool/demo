{
    "markdown": {
        "name": "markdown",
        "tips": "我是 markdown 的描述信息！你可以在这里修改！",
        "noPage": false,
        "contentScript": true,
        "contentScriptCss": true,
        "menuConfig": [
            {
                "icon": "M",
                "text": "我是 markdown",
                "onClick": function (info, tab) {
                    alert("你好，我是markdown!");
                    chrome.DynamicToolRunner({
                        query: "tool=markdown"
                    });
                }
            }
        ],
        "updateUrl": null
    }
}